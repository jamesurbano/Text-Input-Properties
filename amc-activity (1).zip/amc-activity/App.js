
import React, {useState} from 'react';
import {View, TextInput, StyleSheet, Text, Button, Alert} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
const InputwithIcon = () => {
const [fname, setfname] = useState('')
const [lname, setlname] = useState('')
const [age, setage] = useState('')
const [email, setemail] = useState('')
const [pass, setpass] = useState('')  
  const HandleSubmit = () => {
    Alert.alert ('First Name: ' + fname + "\n Last Name: " + lname + "\n Age: " + age + "\n Email: " + email )
  }
  return(
      <View style = {styles.main}>
        <Text style={styles.text}>First Name: </Text>
        <View style = {styles.container}>
          <Ionicons name="person-outline" style={styles.icon} />
          <TextInput
          style={styles.input}
          placeholder="First Name: "
          onChangeText={(text1) => setfname(text1)}
          onSubmitEditing = {HandleSubmit}
          />
        </View>
       
        <Text style={styles.text}>Last Name: </Text>
        <View style = {styles.container}>
          <Ionicons name="person-outline" style={styles.icon} />
          <TextInput
          style={styles.input}
          placeholder="Last Name: "
          onChangeText={(text2) => setlname(text2)}
          />
        </View>
       
        <Text style={styles.text}>Age: </Text>
        <View style = {styles.container}>
          <Ionicons name="calendar-number-outline" style={styles.icon} />
          <TextInput
          style={styles.input}
          placeholder="Age: "
          keyboardType = "phone-pad"
          onChangeText={(text3) => setage(text3)}
          />
        </View>
       
        <Text style={styles.text}>Email Address: </Text>
        <View style = {styles.container}>
          <Ionicons name="mail-outline" style={styles.icon} />
          <TextInput
          style={styles.input}
          placeholder="Email Address: "
          onChangeText={(text4) => setemail(text4)}
          />
        </View>
       
        <Text style={styles.text}>Password: </Text>
        <View style = {styles.container}>
          <Ionicons name="key-outline" style={styles.icon} />
          <TextInput
          style={styles.input}
          placeholder="Password: "
          secureTextEntry = {true}
          maxLength = '10'
          onChangeText = {(value) => setpass(value)}
          />
          <Text> Remaining: {10-pass.length} Characters </Text>
        </View>
        <Button
          style={{fontSize: 20, color: 'green', borderWidth: 2, borderRadius:10, borderColor: 'gray',}}
          onPress={() => HandleSubmit()}
          title="Submit"
        >
          Press Me
</Button>
      </View>
  );
};
const styles = StyleSheet.create({
  main:{
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: 100,
  },
  container: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '80%',
    borderColor: 'gray',
    borderWidth: 2,
    borderRadius:10,
    paddingHorizontal: 10,
  },
  input : {
    height: 40,
    flex: 1,
    fontSize: 16,
  },
  icon: {
    marginRight: 10,
  },
  text: {
    marginTop: 10,
  }
)};
export default InputwithIcon